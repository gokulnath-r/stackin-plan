
var john = ['john','1992','designer']

if (john.indexOf('designer')=== -1){

console.log('john is not a designer');
}else{
 console.log('john is a designer');
}
